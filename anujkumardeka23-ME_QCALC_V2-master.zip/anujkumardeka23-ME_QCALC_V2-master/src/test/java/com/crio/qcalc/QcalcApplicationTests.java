package com.crio.qcalc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QcalcApplicationTests {

	@Test
	void contextLoads() {
	}

}
